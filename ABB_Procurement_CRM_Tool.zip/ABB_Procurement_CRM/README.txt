ABB Procurement CRM Tool
========================
1. Extract this ZIP file
2. Open "ABB_Procurement_CRM.html" in Chrome or Edge browser
3. No installation needed - works fully offline

Features:
- Purchase Orders (grouped by PO#)
- Projects & Suppliers
- BOM Management
- Procurement Planning with IFAT breach alerts
- Import/Export Excel
- Reminders & Activity Log

Built by: ranjithkumar.kuna@in.abb.com
